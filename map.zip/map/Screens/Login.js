import { View, Text, StyleSheet, TextInput, Button, Alert } from "react-native";
import React, { useState } from "react";
import axios from "axios";
import AsyncStorage from "@react-native-async-storage/async-storage";
const Login = ({ navigation }) => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isEmailFocused, setIsEmailFocused] = useState(false);
  const [isPasswordFocused, setIsPasswordFocused] = useState(false);
  const URL = "https://elderly-backend.onrender.com";

  const handleLogin = async () => {
    if (!email || !password) {
      return Alert.alert("Please fill all fields!!");
    }

    try {
      const { data } = await axios.post(`${URL}/user/login`, {
        email: email,
        password: password,
      });
      if (!data?.success) {
        return Alert.alert("User not found");
      }
      if (data?.message === "Password Incorrect") {
        return Alert.alert("Password Incorrect");
      }
      if (data?.success) {
        await AsyncStorage.setItem("userId", data?.user?._id);
        navigation.navigate("Guardian");
      }
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.pageTitle}>LOGIN</Text>
      <View style={styles.box}>
        <View style={styles.inputContainer}>
          <Text>Email</Text>
          <TextInput
            style={[styles.inputBox, isEmailFocused && styles.focusedInputBox]}
            value={email}
            onChangeText={(text) => setEmail(text)}
            onFocus={() => setIsEmailFocused(true)}
            onBlur={() => setIsEmailFocused(false)}
          />
          <Text>PASSWORD</Text>
          <TextInput
            style={[
              styles.inputBox,
              isPasswordFocused && styles.focusedInputBox,
            ]}
            value={password}
            onChangeText={(text) => setPassword(text)}
            secureTextEntry={true}
            onFocus={() => setIsPasswordFocused(true)}
            onBlur={() => setIsPasswordFocused(false)}
          />

          <Button onPress={handleLogin} title="Login" color="#841584" />
        </View>
        <View style={styles.alreadyAccount}>
          <Text style={{ fontSize: 18, fontWeight: "bold" }}>OR</Text>
          <Text style={styles.text}>
            Don't have an account?{" "}
            <Text
              style={styles.link}
              onPress={() => navigation.navigate("Register")}
            >
              REGISTER
            </Text>
          </Text>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    backgroundColor: "#e1d5c9",
    padding: 20,
  },
  pageTitle: {
    fontSize: 40,
    fontWeight: "bold",
    textAlign: "center",
    marginBottom: 20,
    color: "#3b3b3b",
  },
  box: {
    backgroundColor: "#fff",
    borderRadius: 10,
    padding: 20,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
  inputContainer: {
    marginBottom: 20,
  },
  inputBox: {
    height: 40,
    backgroundColor: "#f0f0f0",
    borderRadius: 10,
    marginTop: 10,
    marginBottom: 20,
    paddingLeft: 10,
    color: "#333",
  },
  focusedInputBox: {
    borderWidth: 0,
  },
  pickerContainer: {
    height: 50,
    backgroundColor: "#f0f0f0",
    borderRadius: 10,
    marginBottom: 20,
    justifyContent: "center",
    marginTop: 10,
  },
  picker: {
    height: 50,
    width: "100%",
    borderRadius: 10,
  },
  alreadyAccount: {
    alignItems: "center",
    gap: 8,
  },
  text: {
    fontSize: 16,
  },
  link: {
    fontWeight: "bold",
    textDecorationLine: "underline",
  },
});

export default Login;
