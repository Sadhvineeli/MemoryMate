import { View, Text, StyleSheet, TextInput, Button, Alert } from "react-native";
import React, { useState } from "react";
import axios from "axios";

const Register = ({ navigation }) => {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isNameFocused, setIsNameFocused] = useState(false);
  const [isEmailFocused, setIsEmailFocused] = useState(false);
  const [isPasswordFocused, setIsPasswordFocused] = useState(false);
  const URL = "https://elderly-backend.onrender.com";

  const handleRegister = async () => {
    if (!name || !email || !password) {
      return Alert.alert("Please fill all fields!!");
    }

    if (!validateEmail(email)) {
      console.log("Entter valid email");
      return Alert.alert("Please enter a valid email address!");
    }

    if (!validatePassword(password)) {
      console.log("Entter valid pasword");
      return Alert.alert(
        "Enter a strong passowrd with upperCase & lower case letter with special character and atleast a number!"
      );
    }

    try {
      const { data } = await axios.post(`${URL}/user/register`, {
        name,
        email,
        password,
      });
      if (data?.message === "User already exist") {
        return Alert.alert("User already exist");
      }

      if (data?.success) {
        console.log("Registration successful:", data);
        navigation.navigate("Login");
      } else {
        console.log("Registration failed:", data);
      }
    } catch (error) {
      console.log("API call error:", error);
    }
  };

  const validateEmail = (email) => {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(String(email).toLowerCase());
  };

  const validatePassword = (password) => {
    const minLength = 8;
    const maxLength = 20;
    const hasUpperCase = /[A-Z]/;
    const hasLowerCase = /[a-z]/;
    const hasNumbers = /\d/;
    const hasSpecialChar = /[!@#$%^&*(),.?":{}|<>]/;

    if (password.length < minLength || password.length > maxLength) {
      return false;
    }
    if (!hasUpperCase.test(password)) {
      return false;
    }
    if (!hasLowerCase.test(password)) {
      return false;
    }
    if (!hasNumbers.test(password)) {
      return false;
    }
    if (!hasSpecialChar.test(password)) {
      return false;
    }
    return true;
  };

  return (
    <View style={styles.container}>
      <Text style={styles.pageTitle}>Register</Text>
      <View style={styles.box}>
        <View style={styles.inputContainer}>
          <Text>NAME</Text>
          <TextInput
            style={[styles.inputBox, isNameFocused && styles.focusedInputBox]}
            value={name}
            onChangeText={(text) => setName(text)}
            onFocus={() => setIsNameFocused(true)}
            onBlur={() => setIsNameFocused(false)}
          />
          <Text>Email</Text>
          <TextInput
            style={[styles.inputBox, isEmailFocused && styles.focusedInputBox]}
            value={email}
            onChangeText={(text) => setEmail(text)}
            onFocus={() => setIsEmailFocused(true)}
            onBlur={() => setIsEmailFocused(false)}
          />
          <Text>PASSWORD</Text>
          <TextInput
            style={[
              styles.inputBox,
              isPasswordFocused && styles.focusedInputBox,
            ]}
            value={password}
            onChangeText={(text) => setPassword(text)}
            secureTextEntry={true}
            onFocus={() => setIsPasswordFocused(true)}
            onBlur={() => setIsPasswordFocused(false)}
          />

          <Button onPress={handleRegister} title="Register" color="#841584" />
        </View>

        <View style={styles.alreadyAccount}>
          <Text style={{ fontSize: 18, fontWeight: "bold" }}>OR</Text>
          <Text style={styles.text}>
            Already have an account?{" "}
            <Text
              style={styles.link}
              onPress={() => navigation.navigate("Login")}
            >
              LOGIN
            </Text>
          </Text>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    backgroundColor: "#e1d5c9",
    padding: 20,
  },
  pageTitle: {
    fontSize: 40,
    fontWeight: "bold",
    textAlign: "center",
    marginBottom: 20,
    color: "#3b3b3b",
  },
  box: {
    backgroundColor: "#fff",
    borderRadius: 10,
    padding: 20,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
  inputContainer: {
    marginBottom: 20,
  },
  inputBox: {
    height: 40,
    backgroundColor: "#f0f0f0",
    borderRadius: 10,
    marginTop: 10,
    marginBottom: 20,
    paddingLeft: 10,
    color: "#333",
  },
  focusedInputBox: {
    borderWidth: 0,
  },
  pickerContainer: {
    height: 50,
    backgroundColor: "#f0f0f0",
    borderRadius: 10,
    marginBottom: 20,
    justifyContent: "center",
    marginTop: 10,
  },
  picker: {
    height: 50,
    width: "100%",
    borderRadius: 10,
  },
  alreadyAccount: {
    alignItems: "center",
    gap: 8,
  },
  text: {
    fontSize: 16,
  },
  link: {
    fontWeight: "bold",
    textDecorationLine: "underline",
  },
});

export default Register;
