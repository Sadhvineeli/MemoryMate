import {
  View,
  Text,
  TextInput,
  StyleSheet,
  Modal,
  TouchableOpacity,
  Alert,
  FlatList,
  Image,
} from "react-native";
import React, { useEffect, useState } from "react";
import axios from "axios";
import AsyncStorage from "@react-native-async-storage/async-storage";
const Guardian = ({ navigation }) => {
  const [modalVisible, setModalVisible] = useState(false);
  const [menuVisible, setMenuVisible] = useState(false);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [relation, setRelation] = useState("");
  const [phone, setPhone] = useState("");
  const [id, setId] = useState();
  const [guardians, setGuardians] = useState([]);
  const URL = "https://elderly-backend.onrender.com";

  const handleCreate = async () => {
    try {
      const { data } = await axios.post(`${URL}/user/addGuardian`, {
        name: name,
        email: email,
        relation: relation,
        phone: phone,
        id: id,
      });
      if (data?.success) {
        Alert.alert("Guardian Added");
        setName("");
        setEmail("");
        setRelation("");
        setPhone("");
        setModalVisible(false);
        getGuardian(); // Refresh the funds list
      }
    } catch (error) {
      console.log(error);
    }
  };

  const getGuardian = async () => {
    try {
      const { data } = await axios.post(`${URL}/user/single`, {
        id: id,
      });
      if (data?.success) {
        setGuardians(data?.user?.guardian);
      }
    } catch (error) {
      console.log(error);
    }
  };

  const delGuardian = async (id) => {
    try {
      const { data } = await axios.post(`${URL}/user/del`, {
        id: id,
      });
      if (data?.success) {
        Alert.alert("Guardian Deleted");
        getGuardian();
      }
    } catch (error) {
      console.log(error);
    }
  };
  useEffect(() => {
    const fetchUserId = async () => {
      try {
        const userid = await AsyncStorage.getItem("userId");
        if (userid !== null) {
          setId(userid);
        }
      } catch (error) {
        console.error("Error retrieving user ID:", error);
      }
    };

    fetchUserId();
    getGuardian();
  }, [id]);

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => setMenuVisible(true)}>
          <Text style={styles.menuButton}>Menu</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Add Guardian</Text>
      </View>
      <TouchableOpacity
        style={styles.button}
        onPress={() => setModalVisible(true)}
      >
        <Text style={styles.buttonText}>Add</Text>
      </TouchableOpacity>

      <FlatList
        data={guardians}
        renderItem={({ item }) => (
          <View style={styles.fundItem}>
            <Image
              source={{
                uri: "https://t4.ftcdn.net/jpg/01/91/31/01/360_F_191310138_u5eON8NmILl8r7UKXc4GyGmO7yKdS7TD.jpg",
              }}
              style={styles.fundImage}
            />

            <Text style={styles.fundTotal}>Name: {item?.name}</Text>
            <Text style={styles.fundTotal}>Email: {item?.email}</Text>
            <Text style={styles.fundTotal}>Relation: {item?.relation}</Text>
            <Text style={styles.fundTotal}>Contact: {item?.phone}</Text>
            <Text
              onPress={() => delGuardian(item?._id)}
              style={styles.deleteButton}
            >
              Delete
            </Text>
          </View>
        )}
      />

      <Modal
        animationType="slide"
        transparent={true}
        visible={modalVisible}
        onRequestClose={() => setModalVisible(false)}
      >
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Add Guardian</Text>
            <TextInput
              style={styles.input}
              placeholder="Name"
              value={name}
              onChangeText={setName}
            />

            <TextInput
              style={styles.input}
              placeholder="Email"
              value={email}
              onChangeText={setEmail}
            />
            <TextInput
              style={styles.input}
              placeholder="Relation"
              value={relation}
              onChangeText={setRelation}
            />
            <TextInput
              style={styles.input}
              placeholder="Phone Number"
              value={phone}
              onChangeText={setPhone}
              keyboardType="numeric"
            />
            <TouchableOpacity
              style={styles.createButton}
              onPress={handleCreate}
            >
              <Text style={styles.createButtonText}>Add</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={styles.cancelButton}
              onPress={() => setModalVisible(false)}
            >
              <Text style={styles.cancelButtonText}>Cancel</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      <Modal
        animationType="slide"
        transparent={true}
        visible={menuVisible}
        onRequestClose={() => setMenuVisible(false)}
      >
        <TouchableOpacity
          style={styles.menuOverlay}
          onPress={() => setMenuVisible(false)}
        >
          <View style={styles.menuContent}>
            <Text style={{ fontSize: 30, fontWeight: "bold" }}>MENU</Text>
            <TouchableOpacity
              style={styles.menuItem}
              onPress={() => {
                navigation.navigate("Guardian");
                setMenuVisible(false);
              }}
            >
              <Text style={styles.menuItemText}>Add Guardian</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={styles.menuItem}
              onPress={() => {
                navigation.navigate("Map");
                setMenuVisible(false);
              }}
            >
              <Text style={styles.menuItemText}>Location</Text>
            </TouchableOpacity>
            {/* <TouchableOpacity
              style={styles.menuItem}
              onPress={() => {
                navigation.navigate("Emergency");
                setMenuVisible(false);
              }}
            >
              <Text style={styles.menuItemText}>Emergency</Text>
            </TouchableOpacity> */}
            <TouchableOpacity
              style={styles.menuItem}
              onPress={() => {
                navigation.navigate("Home");
                setMenuVisible(false);
              }}
            >
              <Text style={styles.menuItemText}>Logout</Text>
            </TouchableOpacity>
          </View>
        </TouchableOpacity>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 10,
    marginTop: 20,
    alignItems: "center",
  },
  button: {
    backgroundColor: "#841584",
    padding: 10,
    borderRadius: 5,
    marginTop: 20,
  },
  deleteButton: {
    marginTop: 10,
    backgroundColor: "#FF0000",
    padding: 10,
    borderRadius: 5,
    width: "auto",
    justifyContent: "center",
    alignItems: "center",
    textAlign: "center",
    textDecorationColor: "#FFFFFF",
  },
  pickerContainer: {
    height: 50,
    backgroundColor: "#f0f0f0",
    borderRadius: 10,
    marginBottom: 20,
    justifyContent: "center",
    marginTop: 10,
  },
  picker: {
    height: 50,
    width: "100%",
    borderRadius: 10,
  },
  header: {
    flexDirection: "row",
    width: "100%",
    alignItems: "center",
    justifyContent: "space-between",
    padding: 10,
    borderBottomWidth: 1,
    borderBottomColor: "#ccc",
  },
  menuButton: {
    fontSize: 18,
    fontWeight: "bold",
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: "bold",
    textDecorationLine: "underline",
  },
  menuOverlay: {
    flex: 1,
    backgroundColor: "rgba(0, 0, 0, 0.5)",
    justifyContent: "flex-start",
    alignItems: "flex-start",
  },
  menuContent: {
    backgroundColor: "#fff",
    width: 250,
    height: "100%",
    padding: 20,
  },
  menuItem: {
    marginBottom: 20,
  },
  menuItemText: {
    fontSize: 18,
    fontWeight: "bold",
    marginTop: 40,
  },
  buttonText: {
    color: "#fff",
    fontSize: 16,
  },
  fundItem: {
    backgroundColor: "#f9f9f9",
    padding: 15,
    marginVertical: 8,
    borderRadius: 10,
    width: "100%",
    marginTop: 40,
    alignItems: "stretch",
    justifyContent: "center",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
    overflow: "scroll",
  },
  fundImage: {
    width: "auto",
    height: 200,
    marginBottom: 10,
    borderRadius: 10,
    minWidth: 300,
  },
  fundName: {
    fontSize: 18,
    fontWeight: "bold",
  },
  fundTotal: {
    fontSize: 16,
    color: "#555",
  },
  modalContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "rgba(0, 0, 0, 0.5)",
  },
  modalContent: {
    backgroundColor: "#fff",
    padding: 20,
    borderRadius: 10,
    width: "80%",
  },
  modalTitle: {
    fontSize: 20,
    marginBottom: 20,
    textAlign: "center",
  },
  input: {
    height: 40,
    borderColor: "#ccc",
    borderWidth: 1,
    marginBottom: 20,
    padding: 10,
    borderRadius: 5,
  },
  label: {
    fontSize: 16,
    marginBottom: 10,
  },
  dateText: {
    height: 40,
    borderColor: "#ccc",
    borderWidth: 1,
    marginBottom: 20,
    padding: 10,
    borderRadius: 5,
    lineHeight: 40,
  },
  createButton: {
    backgroundColor: "#841584",
    padding: 10,
    borderRadius: 5,
    marginBottom: 10,
    alignItems: "center",
  },
  createButtonText: {
    color: "#fff",
    fontSize: 16,
  },
  cancelButton: {
    backgroundColor: "#ccc",
    padding: 10,
    borderRadius: 5,
    alignItems: "center",
  },
  cancelButtonText: {
    color: "#333",
    fontSize: 16,
  },
});

export default Guardian;
