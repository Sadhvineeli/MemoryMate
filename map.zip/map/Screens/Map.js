import React, { useState, useEffect } from "react";
import MapView, { Marker } from "react-native-maps";
import {
  StyleSheet,
  View,
  Button,
  Modal,
  Text,
  Alert,
  TouchableOpacity,
  Vibration,
} from "react-native";
import * as Location from "expo-location";
import * as Linking from "expo-linking";
import Communications from "react-native-communications";
import AsyncStorage from "@react-native-async-storage/async-storage";
import axios from "axios";

export default function Map({ navigation }) {
  const [modalVisible, setModalVisible] = useState(false);
  const [id, setId] = useState();
  const [menuVisible, setMenuVisible] = useState(false);
  const [guardian, setGuardian] = useState([]);
  const [selectedGuardian, setSelectedGuardian] = useState(null);
  const URL = "https://elderly-backend.onrender.com";
  const [mapregion, setmapregion] = useState({
    latitude: 37.78825,
    longitude: -122.4324,
    latitudeDelta: 0.0922,
    longitudeDelta: 0.0421,
  });

  const userLocation = async () => {
    let { status } = await Location.requestForegroundPermissionsAsync();
    if (status !== "granted") {
      const error = "Permission to access location was denied";
    }
    let location = await Location.getCurrentPositionAsync({
      enableHighAccuracy: true,
    });
    setmapregion({
      latitude: location.coords.latitude,
      longitude: location.coords.longitude,
      latitudeDelta: 0.0922,
      longitudeDelta: 0.0421,
    });
    console.log(mapregion);
  };

  const getUser = async () => {
    try {
      const { data } = await axios.post(`${URL}/user/single`, {
        id: id,
      });

      if (data?.success) {
        setGuardian(data?.user?.guardian);
      }
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    userLocation();
    const fetchUserId = async () => {
      try {
        const userid = await AsyncStorage.getItem("userId");
        if (userid !== null) {
          setId(userid);
        }
      } catch (error) {
        console.error("Error retrieving user ID:", error);
      }
    };

    fetchUserId();
    getUser();
  }, [id]);

  const openInMaps = () => {
    setModalVisible(true);
  };

  const sendLocationToGuardian = (guardian) => {
    const url = `https://www.google.com/maps?q=${mapregion.latitude},${mapregion.longitude}`;
    const message = `Please help me I'm in danger: ${url}`;
    Communications.textWithoutEncoding(String(guardian.phone), message);
    Vibration.vibrate([500, 500, 500]);
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => setMenuVisible(true)}>
          <Text style={styles.menuButton}>Menu</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Location</Text>
      </View>
      <Modal
        animationType="slide"
        transparent={true}
        visible={menuVisible}
        onRequestClose={() => setMenuVisible(false)}
      >
        <TouchableOpacity
          style={styles.menuOverlay}
          onPress={() => setMenuVisible(false)}
        >
          <View style={styles.menuContent}>
            <Text style={{ fontSize: 30, fontWeight: "bold" }}>MENU</Text>
            <TouchableOpacity
              style={styles.menuItem}
              onPress={() => {
                navigation.navigate("Guardian");
                setMenuVisible(false);
              }}
            >
              <Text style={styles.menuItemText}>Add Guardian</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={styles.menuItem}
              onPress={() => {
                navigation.navigate("Map");
                setMenuVisible(false);
              }}
            >
              <Text style={styles.menuItemText}>Location</Text>
            </TouchableOpacity>
            {/* <TouchableOpacity
              style={styles.menuItem}
              onPress={() => {
                navigation.navigate("Emergency");
                setMenuVisible(false);
              }}
            >
              <Text style={styles.menuItemText}>Emergency</Text>
            </TouchableOpacity> */}
            <TouchableOpacity
              style={styles.menuItem}
              onPress={() => {
                navigation.navigate("Home");
                setMenuVisible(false);
              }}
            >
              <Text style={styles.menuItemText}>Logout</Text>
            </TouchableOpacity>
          </View>
        </TouchableOpacity>
      </Modal>
      <Modal
        animationType="slide"
        transparent={true}
        visible={modalVisible}
        onRequestClose={() => setModalVisible(false)}
      >
        <View style={styles.modalContainer}>
          <Text style={styles.modalTitle}>Select Guardian</Text>
          {guardian?.length < 1 ? (
            <Text style={styles.modalTitle}>No Guardians Added</Text>
          ) : null}
          {guardian.map((guardian) => (
            <TouchableOpacity
              key={guardian.id}
              style={styles.guardianItem}
              onPress={() => {
                setSelectedGuardian(guardian);
                setModalVisible(false);
                sendLocationToGuardian(guardian);
              }}
            >
              <Text>{guardian.name}</Text>
            </TouchableOpacity>
          ))}
          <TouchableOpacity
            style={styles.closeButton}
            onPress={() => setModalVisible(false)}
          >
            <Text>Close</Text>
          </TouchableOpacity>
        </View>
      </Modal>

      <MapView style={styles.map} region={mapregion}>
        <Marker coordinate={mapregion} title="Marker" />
      </MapView>
      <View style={styles.buttonContainer}>
        <Button title="Share Location" onPress={openInMaps} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 10,
    marginTop: 20,
    alignItems: "center",
  },
  map: {
    width: "100%",
    height: "90%",
  },
  buttonContainer: {
    position: "absolute",
    bottom: 20,
    left: 20,
    right: 20,
  },
  header: {
    flexDirection: "row",
    width: "100%",
    alignItems: "center",
    justifyContent: "space-between",
    padding: 10,
    borderBottomWidth: 1,
    borderBottomColor: "#ccc",
  },
  modalContainer: {
    backgroundColor: "#fff",
    padding: 20,
    margin: 50,
    borderRadius: 10,
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
    marginTop: 200,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: "bold",
    marginBottom: 10,
  },
  guardianItem: {
    padding: 10,
    borderBottomWidth: 1,
    borderBottomColor: "#ccc",
  },
  closeButton: {
    marginTop: 10,
    alignItems: "center",
  },
  menuButton: {
    fontSize: 18,
    fontWeight: "bold",
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: "bold",
    textDecorationLine: "underline",
  },
  menuOverlay: {
    flex: 1,
    backgroundColor: "rgba(0, 0, 0, 0.5)",
    justifyContent: "flex-start",
    alignItems: "flex-start",
  },
  menuContent: {
    backgroundColor: "#fff",
    width: 250,
    height: "100%",
    padding: 20,
  },
  menuItem: {
    marginBottom: 20,
  },
  menuItemText: {
    fontSize: 18,
    fontWeight: "bold",
    marginTop: 40,
  },
});
